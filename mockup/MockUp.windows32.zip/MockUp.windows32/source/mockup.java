import processing.core.*; 
import processing.data.*; 
import processing.event.*; 
import processing.opengl.*; 

import java.util.HashMap; 
import java.util.ArrayList; 
import java.io.File; 
import java.io.BufferedReader; 
import java.io.PrintWriter; 
import java.io.InputStream; 
import java.io.OutputStream; 
import java.io.IOException; 

public class mockup extends PApplet {

boolean[][] walls = new boolean[10][10];
PImage wall;
PImage floor;
PImage player;
PVector pLoc;
ArrayList<Character> keys = new ArrayList<Character>();
boolean collide = false;
float speed = 2;


public void setup() {
  size(1000, 1000);
  pLoc = new PVector(350, 650, 1);
  wall = loadImage("wall.png");
  floor = loadImage("floor.png");
  player = loadImage("miner.png");
  player.resize(70, 0);
  loadMap();
}

public void draw() {
  background(200);
  walls();
  pointer();
  control();
  player();
  physics();
}

/*
go through both x and y
then take the location add the players location to it
then render the ones on the screen
*/

public void keyTyped() {
  if(key == 'p') {
    saveMap();
  }
}

public void keyPressed() {
  if(!keys.contains(key)) {
    keys.add(key);
  }
}

public void keyReleased() {
  if(keys.contains(key)) {
    keys.remove(keys.indexOf(key));
  }
}

public void control() {
  ArrayList<Character> temp = keys;
  for(char i : temp) {
    if(i == 'w') {
      pLoc.y -= speed;
    }
    
    if(i == 's') {
      pLoc.y += speed;
    }
    
    if(i == 'a') {
      pLoc.x -= speed;
    }
    
    if(i == 'd') {
      pLoc.x += speed;
    }
  }
}

public void player() {
  pushMatrix();
  translate(pLoc.x, pLoc.y);
  rotate(PI/pLoc.z);
  image(player, -player.width/2, -player.height/2);
  noFill();
  if(collide){
    stroke(255,0,0);
  } else {
    stroke(0,255,0);
  }
  ellipse(0, 0, 75, 75);
  popMatrix();
}

public void physics() {
  PVector rot = new PVector(0, -37.5f);
  int boom = 0;
  int iter = 20;
  PVector bounce = new PVector(0,0);
  for(int r = 0; r < iter; r++){
    PVector test = PVector.add(rot, pLoc);
    int[] sq = getRect(test);
    fill(0);
    ellipse(test.x, test.y, 2, 2);
    if(walls[sq[0]][sq[1]]){
      PVector face = rot.get();
      face.rotate(PI);
      face.setMag(speed);
      bounce.add(face);
      boom++;
    }
    rot.rotate(PI * 2 /iter);
  }
  
  if(boom == 0){
    collide = false;
  } else {
    pLoc.add(bounce);
    collide = true;
  }
}

public int[] getRect(PVector loc) {
  int x = floor(loc.x / 100);
  int y = floor(loc.y / 100);
  return new int[] {x, y};
}

public PVector mouseLoc() {
 return new PVector(mouseX, mouseY);
}

public void mousePressed() {
  int[] loc = getRect(mouseLoc());
  walls[loc[0]][loc[1]] = !walls[loc[0]][loc[1]];
}

public void pointer() {
  noFill();
  stroke(255,0,0);
  int[] loc = getRect(mouseLoc());
  int mx = loc[0] * 100;
  int my = loc[1] * 100;
  rect(mx, my, 100, 100);
}

public void walls() {
  for(int x = 0; x < walls.length; x++) {
    for(int y = 0; y < walls.length; y++) {
      if(walls[x][y]){
        image(wall, x*100, y*100);
      } else {
        image(floor, x*100, y*100);
      }
    }
  }
}

public void saveMap() {
  PrintWriter output = createWriter("data/world.txt");
  String line = "";
  println("saving map!");
  for(int y = 0; y < walls.length; y++) {
    for(int x = 0; x < walls.length; x++) {
      if(walls[x][y]){
        line = line + "1";
      } else {
        line = line + "0";
      }
      
      if(x != 9) {
        line = line + ",";
      }
    }
    println(line);
    output.println(line);
    line = "";
  }
  output.close();
  println("saved!");
}

public void loadMap() {
  BufferedReader reader = createReader("world.txt");
  String line = null;
  int y = 0;
  
  while(true){
    try {
      line = reader.readLine();
    } catch (IOException e){
      e.printStackTrace();
      line = null;
    }
    
    if (line == null) {
      break; 
    } else {
      String[] pieces = split(line, ',');
      for(int x = 0; x < pieces.length; x++) {
        if(Integer.valueOf(pieces[x]) == 1) {
          walls[x][y] = true;
        } else {
          walls[x][y] = false;
        }
      }   
      y++;
    }
  }
  try {
    reader.close();
  } catch (IOException e){
    e.printStackTrace();
  }
}
  static public void main(String[] passedArgs) {
    String[] appletArgs = new String[] { "mockup" };
    if (passedArgs != null) {
      PApplet.main(concat(appletArgs, passedArgs));
    } else {
      PApplet.main(appletArgs);
    }
  }
}
